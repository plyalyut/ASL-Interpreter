exports.home = (req, res) => {
  res.render('../views/home');
};

exports.about = (req, res) => {
  res.render('../views/about');
}
