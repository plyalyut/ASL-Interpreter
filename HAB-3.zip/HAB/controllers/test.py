print "HI"
